# Lyra 射击训练场教学增量

本包来自 Lyra 学习手册：https://wangshuxian6.github.io/Lyra/ 。主体为原创教学增量，不包含官方 Lyra 的 .uasset/.umap、完整源码插件、美术、地图或第三方库二进制。训练包另含明确标注来源的官方蓝图原生节点文本。

保留当前 examples/ 与 scripts/ 目录层次。在 Windows PowerShell 7 中，从本文件所在目录运行：

    ./scripts/prepare-labs.ps1 -LyraRoot 'F:/UE/LyraStarterGame' -LabsRoot 'F:/UE/LyraDocLabs' -Lab Training

先从 Epic 获取与你的引擎对应的 Lyra。脚本只从指定的本地官方项目复制依赖，并在 LabsRoot 下准备实验工程。训练场的地图、Experience 和 PawnData 由 prepare_training.py 在本地实验副本中生成，不分发官方资产的副本。

public/blueprints/lyra/ 下的 Jump EventGraph、Dash SelectDirectionalMontage 和 W_OverallUILayout EventGraph 文本来自本机 Epic Lyra 原始蓝图，供 scripts/verify-training-blueprints.py 在完整依赖的实验副本中导入编译。它们不是本项目原创蓝图；具体原始资产、图名、文件哈希见 MANIFEST.json 的 externalMaterials，并参阅 NOTICE.md。请保留 public/ 目录层次。

MANIFEST.json 记录包内每个源文件的相对路径、字节数和 SHA-256。下载页另提供整个 tar.gz 的 SHA256SUMS.txt。源代码文件和资产并不等同于所有运行场景已经通过；查看随包验证记录及教程当前验收说明。
