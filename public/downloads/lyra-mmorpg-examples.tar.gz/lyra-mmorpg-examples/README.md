# MMORPG 原创教学工程

本包来自 Lyra 学习手册：https://wangshuxian6.github.io/Lyra/ 。主体为原创教学增量，不包含官方 Lyra 的 .uasset/.umap、完整源码插件、美术、地图或第三方库二进制。训练包另含明确标注来源的官方蓝图原生节点文本。

保留当前 examples/ 与 scripts/ 目录层次。在 Windows PowerShell 7 中，从本文件所在目录运行：

    ./scripts/prepare-labs.ps1 -LyraRoot 'F:/UE/LyraStarterGame' -LabsRoot 'F:/UE/LyraDocLabs' -Lab MMORPG

先从 Epic 获取与你的引擎对应的 Lyra。脚本只从指定的本地官方项目复制依赖，并在 LabsRoot 下准备实验工程。训练场的地图、Experience 和 PawnData 由 prepare_training.py 在本地实验副本中生成，不分发官方资产的副本。

MMORPG 包含 31 个原创教学 .uasset、C++/Config、Game Feature、独立后端 Program、SQL 迁移与验证脚本。详细构建/运行步骤见 examples/MMORPG/README.md 和 examples/MMORPG/backend/README.md。第三方依赖由 scripts/backend/Prepare-Dependencies.ps1 下载/定位，数据库凭据在本机初始化时生成，包中没有预置密码。

MANIFEST.json 记录包内每个源文件的相对路径、字节数和 SHA-256。下载页另提供整个 tar.gz 的 SHA256SUMS.txt。源代码文件和资产并不等同于所有运行场景已经通过；查看随包验证记录及教程当前验收说明。
